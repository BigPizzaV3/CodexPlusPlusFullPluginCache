# Testing ecommerce.1688-product-detail

## Static and mock gates

- Compile `scripts/alibaba1688_product_detail.py` with Python.
- Verify the request URL begins with `/api/v1/tools/research/`, authentication uses `Bearer`, and timeout remains compatible with the source contract.
- Mock a successful Nexscope envelope (`code=0`, business object in `data`), an outer failure, HTTP 401, HTTP 402, malformed JSON, and a network failure.
- Verify full responses are stored below `nexscope/<date>/<session>/data` and secrets are never written.

## English invocation checks

1. Query the documented public entity with the smallest valid request and summarize the result.
2. Explain the expected credit cost before requesting a second page, region, or paid operation.
3. Reject an undocumented parameter without making a request.

## Live test evidence

Record the timestamp, test base URL, redacted request, HTTP status, outer `code`, inner status, `traceId`, server-reported `X-Cost-Token` and `X-Cost-Credit`, and saved response path. A paid live call consumes credits, requires explicit approval, and must not be retried automatically.

## NEX-198 validation evidence

- Static/frontmatter/manifest and offline Mock checks: passed.
- 2026-08-27 test Curl: HTTP 200, outer `code=0`, inner `errcode=200`; raw header and body saved under `transfer/test-results/public-ecommerce-migration/`.
- External Curl did not expose upstream billing headers; backend monitoring `response.headers` supplied array-valued evidence. `X-Cost-Token=1500`, calculated credits `1.5615`, reported `X-Cost-Credit=1`, trace `6807070eba0800d650088368e7ab6f28`. Do not substitute body `costToken`.
- ZIP/local install: passed in the isolated `transfer/test-results/public-ecommerce-migration/local-install/skills` root.
- Production publication: not performed.
