---
name: ecommerce.amazon-asin-keywords
description: Use SIF data to reverse-lookup traffic keywords for any Amazon ASIN, including organic ranking, ad ranking, search volume, traffic share, organic/paid scores, ABA TOP3 click concentration, click conversion rate, year-over-year search volume changes, and weekly/monthly time windows. Trigger when the user mentions ASIN keyword analysis, ASIN reverse lookup, traffic keyword research, organic ranking query, ad ranking query, keyword position tracking, SIF keyword data, competitor keyword peeking, viewing which keywords drive traffic to a product, analyzing keyword performance for a specific ASIN, time windows by week/month/recent N days, ASIN reverse keyword lookup, traffic keywords, organic ranking, ad ranking, search volume, SIF keywords, competitor keyword reverse lookup, click concentration, click-to-purchase conversion, week-over-week search volume. Even if the user does not explicitly mention "SIF", if their need involves finding keywords associated with a specific Amazon product (ASIN), this skill should also be triggered.
---

# SIF ASIN Keyword Analysis

This skill guides you on how to query and analyze traffic keywords for a specific Amazon ASIN, helping Amazon sellers understand which keywords drive traffic to a product and how that product ranks for each keyword.

## Core Concepts

SIF ASIN Keyword data reveals the keywords that bring traffic to a specific Amazon product (ASIN). For each keyword, you can see the product's organic search rank, SP ad rank, search volume, traffic share, display position types, and various performance markers. This is the go-to tool for reverse ASIN keyword lookup.

**Single-ASIN limitation**: This tool queries one ASIN at a time. If the user wants to compare multiple ASINs, you must make separate queries for each.

**Ranking logic**: A smaller rank value means a better (higher) position. Rank 1 means the product appears first in search results. When a user says "ranking improved", the numeric value decreased; "ranking dropped" means the value increased.

## Data Fields

### Per-keyword record (each element of `data`)

| Field | API Name | Description | Example |
|-------|----------|-------------|---------|
| Keyword | keyword | The search keyword driving traffic | wireless charger |
| Keyword Translation | translateKeyword | Localized keyword translation for the marketplace | — |
| ASIN | asin | The product ASIN being queried | B0XXXXXXXX |
| Organic Rank | productNaturalRank | Product's position in organic search results | 5 |
| Organic Rank (Display) | naturalRankDisplay | Organic rank as display text | 5 |
| Ad Rank | productAdRank | Product's position in SP ad results | 3 |
| Ad Rank (Display) | adRankDisplay | Ad rank as display text | 3 |
| Weekly Search Volume | weeklySearchVolume | Estimated weekly searches for this keyword | 125000 |
| Keyword Popularity Rank | keywordPopularityRank | Keyword's search volume rank among all keywords (lower = more popular) | 203 |
| Total Search Result Products | totalSearchResultProductCount | Total products shown under this keyword (organic + ads + recommendations) | 1280 |
| Traffic Share | trafficShare | Share of traffic this keyword contributes to the ASIN (1 = 100%) | 0.05 |
| Natural Traffic Share | naturalTrafficShare | Organic exposure score / total score | 0.62 |
| Paid Traffic Share | paidTrafficShare | Paid-ad exposure score / total score (SP + SB + SBV + recAd) | 0.31 |
| Natural Traffic Score | naturalTrafficScore | Organic search exposure score for this ASIN on this keyword (0 = none) | 4.2 |
| SP Ads Score | sponsoredProductsScore | Sponsored Products regular-slot score (excludes SP recommendation slots) | 2.1 |
| Brand Ad (SB) Score | brandAdScore | Sponsored Brands total score (standard + video) | 0.8 |
| Video Ad (SBV) Score | videoAdScore | Sponsored Brands Video score | 0.3 |
| SP Recommendation Score | sponsoredRecommendationScore | Combined score across SP recommendation slots (Trending now, Seen on social media, Customers frequently viewed, 4 stars and above, etc.) | 1.4 |
| SP Recommendation Breakdown | sponsoredRecommendationBreakdown | Array of `{title, score, scoreRatio}` per SP recommendation slot | [{"title":"Trending now","score":0.8,"scoreRatio":0.57}] |
| ABA TOP3 Click Concentration | clickConcentrationShare | Whether clicks under this keyword concentrate on the top ASINs (NOT a conversion rate) | 0.42 |
| Click-to-Purchase Conversion | clickToPurchaseConversionRate | `purchaseQty / clickQty` at the keyword level | 0.037 |
| Display Position Types | displayPositionTypes | Where the product appears: natural, ac, sp, top, bottom, er, vedio, tr, trfob | ["natural", "sp"] |
| Traffic Characteristic Markers | trafficCharacteristicMarkers | Traffic feature tags: isMainKw, isAccurateKw, isAccurateAboveKw, isAccurateTailKw | ["isMainKw"] |
| Conversion Performance Markers | conversionPerformanceMarkers | Conversion tags: isPurchaseKw, isQualityKw, isStableKw, isLossKw, isInvalidKw | ["isPurchaseKw"] |
| Last Organic Rank Time | lastNaturalRankTime | When the product last had a valid organic rank for this keyword | 2026-04-20 |
| Last Ad Rank Time | lastAdRankTime | When the product last had a valid SP ad rank for this keyword | 2026-04-20 |
| Period End Date | periodEndDate | End date of the current (weekly) period = start-week + 7 days | 2026-04-27 |
| Update Time | updateTime | When the keyword data was last updated | 2026-04-21 |

### Top-level response fields (alongside `data`)

| Field | API Name | Description |
|-------|----------|-------------|
| Is Parent ASIN | isParentAsin | Whether the queried ASIN is a parent (variation hub) |
| Has Variants | hasVaiants | Whether the ASIN has variants |
| Latest ABA Week | abaCreateDateWeek | Latest ABA weekly data reference date |

## Supported Marketplaces

13 marketplaces: US (United States), UK (United Kingdom), DE (Germany), CA (Canada), JP (Japan), FR (France), ES (Spain), IT (Italy), MX (Mexico), AU (Australia), AE (United Arab Emirates), BR (Brazil), SA (Saudi Arabia).

Default marketplace is **US**. Use US when the user does not specify a marketplace. Codes outside this list will be rejected by the API pattern.

## How to Invoke

- **API Endpoint**: `POST /sif/asinKeywords` (complete params/response/error codes in `references/api.md`)
- **Python Script**: `python scripts/amazon_asin_keywords.py '<JSON params>' [--inline]`
- **Cost constraint**: This tool consumes credits; the same session and parameter combination is called only once by default, with a 24h local cache in the script. On failure or empty results, do not automatically retry with different keywords, pagination, or postal codes; inform the user about additional consumption before continuing to search.

**Output strategy (script default behavior)**:
- **Always** write the full response to `<cwd>/nexscope/<YYYY-MM-DD>/<session>/data/nexscope-sif-asin-keywords-<timestamp>.json` (`<cwd>` is the working directory at script execution time, i.e. the current project directory in Claude Code; `<session>` is taken from the `SESSION_ID` env var, auto-grouped by user task; **do not write to /tmp**, error if current directory is not writable)
- Response body <= 8 KB: print full JSON to stdout after saving
- Response body > 8 KB: print only summary to stdout after saving (top-level fields, common counts like `total`/`costToken`, length of largest list field + first 3 samples)
- Add `--inline` to force full output to stdout (still saves to disk)

**Data reading tip**: Check the summary first to decide if it's enough; when specific fields are needed, prefer using `jq` or `ConvertFrom-Json` to extract from the saved json file on demand, avoiding loading the entire JSON into context.

## Parameter Guide

### Required Parameter

- **asin** (string, required): The Amazon ASIN to look up. Only one ASIN per request.

### Optional Parameters

- **country** (string, default `US`): Marketplace code. See Supported Marketplaces above.
- **keyword** (string): Filter results to keywords containing this text. Translate the keyword into the language of the target marketplace when possible.
- **timePieceType** (string, default `latelyDay`): Time window type -- `latelyDay` (most recent N days), `month` (specific month), `week` (specific week).
- **timePieceValue** (string, default `7`): Value paired with `timePieceType`.
  - When `timePieceType=latelyDay` -> only `7` or `30` are supported
  - When `timePieceType=month` -> `YYYY-MM` (e.g. `2026-04`)
  - When `timePieceType=week` -> the week's start date `YYYY-MM-DD` (e.g. `2026-04-13`)
- **conditions** (string): Comma-separated condition filters. Flag-style filters:
  - `nfPosition` -- organic traffic keywords
  - `isSpAd` -- SP ad keywords
  - `isBrandAd` -- brand ad keywords
  - `isVedioAd` -- video ad keywords
  - `isAC` -- Amazon's Choice keywords
  - `isAccurateKw` -- precise traffic keywords
  - `isAccurateTailKw` -- precise long-tail keywords
  - `isPurchaseKw` -- purchase-converting keywords
  - `isQualityKw` -- high-quality conversion keywords
  - `isStableKw` -- stable conversion keywords
  - `isLossKw` -- conversion-loss keywords
  - `isInvalidKw` -- invalid-exposure keywords
  - `isMultiVariantKw` -- keywords ranking organically across multiple variants
  - `isSearchVolUpKw` -- keywords whose search volume increased year-over-year
  - `isSearchVolDownKw` -- keywords whose search volume decreased year-over-year

  Period-count filters (all / new-in):
  - `totalPeriod.in` -- newly-entered traffic keywords this period
  - `nfKeywordCnt.total` / `nfKeywordCnt.in` -- keywords with (new) organic exposure
  - `adKeywordCnt.total` / `adKeywordCnt.in` -- keywords with (new) ad exposure
  - `allSpKeywordCnt.total` / `allSpKeywordCnt.in` -- (new) SP-ad keywords (regular + recommendation)
  - `spKeywordCnt.total` / `spKeywordCnt.in` -- (new) SP regular keywords
  - `recSpKeywordCnt.total` / `recSpKeywordCnt.in` -- (new) SP recommendation keywords
  - `allSbKeywordCnt.total` / `allSbKeywordCnt.in` -- (new) SB-ad keywords
  - `sbKeywordCnt.total` / `sbKeywordCnt.in` -- (new) SB regular keywords
  - `sbvKeywordCnt.total` / `sbvKeywordCnt.in` -- (new) SBV keywords
- **sortBy** (string): Sort field. Options: `lastRank` (organic rank), `adLastRank` (ad rank), `updateTime` (update time), `searchesRank` (search popularity rank), `estSearchesNum` (monthly search volume).
- **desc** (boolean, default `true`): Sort in descending order. Set to `false` for ascending.
- **pageNum** (integer, default `1`): Page number for pagination.
- **pageSize** (integer, default `100`, range 10-100): Number of results per page.

### Building Effective Queries

1. **Always specify the marketplace**: Set `country` to one of the 13 supported codes.
2. **Pick the right time window**: The default is the latest 7 days. Pass `timePieceType=month` + `timePieceValue=YYYY-MM` for a specific month, or `timePieceType=week` + `timePieceValue=YYYY-MM-DD` for a specific ABA week.
3. **Use keyword filtering**: When the user is interested in specific keywords, pass the `keyword` parameter to narrow results.
4. **Apply condition filters**: Use `conditions` to focus on specific keyword types (e.g., only organic keywords, only purchase-converting keywords, or newly-entered SP keywords via `spKeywordCnt.in`).
5. **Choose appropriate sorting**: Sort by `estSearchesNum` for highest search volume keywords, or by `lastRank` for best-ranking keywords.
6. **Handle pagination**: The API returns at most 100 results per page. Use `pageNum` to retrieve additional pages if the total exceeds 100.

## Usage Examples

**1. Find all traffic keywords for an ASIN on the US marketplace**
```
asin: "B0XXXXXXXX", country: "US"
```

**2. Find organic traffic keywords only**
```
asin: "B0XXXXXXXX", country: "US", conditions: "nfPosition"
```

**3. Find keywords containing "charger" sorted by search volume (ascending)**
```
asin: "B0XXXXXXXX", country: "US", keyword: "charger", sortBy: "estSearchesNum", desc: false
```

**4. Find high-converting keywords**
```
asin: "B0XXXXXXXX", country: "US", conditions: "isPurchaseKw,isQualityKw"
```

**5. Find SP ad keywords on the Japan marketplace**
```
asin: "B0XXXXXXXX", country: "JP", conditions: "isSpAd", sortBy: "adLastRank", desc: false
```

**6. Find precise long-tail keywords with stable conversion**
```
asin: "B0XXXXXXXX", country: "US", conditions: "isAccurateTailKw,isStableKw"
```

**7. Find newly-entered SP traffic keywords in April 2026**
```
asin: "B0XXXXXXXX", country: "US", timePieceType: "month", timePieceValue: "2026-04", conditions: "spKeywordCnt.in"
```

**8. Find keywords whose search volume is trending up**
```
asin: "B0XXXXXXXX", country: "US", conditions: "isSearchVolUpKw", sortBy: "estSearchesNum", desc: true
```

## Display Rules

1. **Present data only**: Show query results in clear tables without subjective business advice.
2. **Ranking clarification**: When showing ranking data, remind users that lower numeric values mean better (higher) positions.
3. **Share formatting**: Display `trafficShare`, `naturalTrafficShare`, `paidTrafficShare`, and `clickConcentrationShare` as percentages (multiply by 100). For example, 0.05 should be shown as 5%.
4. **Click concentration wording**: `clickConcentrationShare` measures how concentrated clicks are on top ASINs under the keyword -- it is NOT a conversion rate. Label it clearly so users don't confuse it with `clickToPurchaseConversionRate`.
5. **Period disclosure**: When showing counts sourced from `*.in`/`*.total` filters or comparing numbers, annotate the period range -- default is last 7 days; if `timePieceType=month` or `week` is set, surface the resolved period (`periodEndDate` / `abaCreateDateWeek`).
6. **Marker translation**: Translate marker arrays into human-readable labels. For example, `["isMainKw", "isAccurateKw"]` should display as "Main Traffic, Precise Traffic".
7. **Display position translation**: Translate position type arrays into readable labels: natural = Organic, ac = Amazon's Choice, sp = SP Ad, top = Top Brand Ad, bottom = Bottom Brand Ad, er = Editorial Recommendation, vedio = Video Ad, tr = Top Rated, trfob = Top Rated Frequently Bought.
8. **Pagination notice**: When results have more pages, inform the user of the total count and suggest fetching additional pages.
9. **Error handling**: When a query fails, explain the reason based on the `msg` field and suggest adjusting query parameters.
10. **Multi-ASIN requests**: If the user asks about multiple ASINs, make separate API calls for each and present the results together.
## Important Limitations

- **Single ASIN per request**: Only one ASIN can be queried at a time.
- **Page size cap**: Maximum 100 results per page.
- **Time window granularity**: `timePieceType=latelyDay` only supports `timePieceValue=7` or `30`; arbitrary N-day windows are not supported.
- **Marketplace coverage**: 13 marketplaces only -- IN / NL / SE / PL / TR / SG are no longer available.
- **Keyword language**: The `keyword` filter should ideally be in the language of the target marketplace.

## User Expression & Scenario Quick Reference

**Applicable** -- Keyword analysis for specific Amazon products:

| User Says | Scenario |
|-----------|----------|
| "What keywords does this ASIN rank for" | Reverse ASIN keyword lookup |
| "Show me the traffic keywords for B0XXX" | Traffic keyword analysis |
| "What's the organic rank for this product" | Organic ranking check |
| "Which keywords is this product advertising on" | Ad keyword analysis |
| "Find high-converting keywords for this ASIN" | Conversion keyword mining |
| "What are the main traffic sources for this product" | Main traffic keyword identification |
| "Show me keywords with lost conversions" | Conversion loss diagnosis |
| "Which keywords have Amazon's Choice badge" | AC keyword discovery |
| "Compare keyword rankings for my ASIN" | Keyword position analysis |
| "Which new SP keywords did this ASIN get last month" | New-in period keyword discovery (`spKeywordCnt.in` + month window) |
| "Keywords whose search volume is trending up YoY" | Search-volume trend filter (`isSearchVolUpKw`) |
| "Is click concentration high on this keyword" | ABA TOP3 click concentration read |
| "Keyword click-to-purchase conversion" | Per-keyword conversion check |

**Not applicable** -- Needs beyond single-ASIN keyword lookup:
- Broad keyword research not tied to a specific ASIN (use ABA data tools instead)
- Product reviews, listing copywriting
- Sales estimation, revenue analysis
- Advertising campaign management (bids, budgets)
- Category-wide keyword trends without a specific ASIN

## Authentication

Set the `NEXSCOPE_API_KEY` environment variable. If credentials are missing or expire, visit https://www.nexscope.ai/help/skills-external-access?co-from=skillNS to top up credits.
